using UnityEngine;

public class Hospital : Service
{
    [Header("Hospital Setup")]
    [SerializeField] private int maxAmbulances = 3;
    private int currentAmbulances = 3;

    public bool HasAmbulances()
    {
        return (currentAmbulances > 0);
    }

    public bool DispatchAmbulance()
    {
        if (currentAmbulances > 0)
        {
            currentAmbulances--;
            return true;
        }
        else
        {
            return false;
        }
    }

    public void AmbulanceReturned()
    {
        if(currentAmbulances == maxAmbulances)
        {
            Debug.LogError("Somehow more ambulances returned than dispatched.");
            return;
        }

        currentAmbulances += 1;
    }
}
