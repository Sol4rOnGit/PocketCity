using UnityEngine;

public class House : Building
{
    [Header("Building Vars")]
    [SerializeField] private int _maxResidents = 5;
    public int maxResidents => _maxResidents;
    public int residents;
    public float happiness; //0-100

    [HideInInspector] public int daysWithLowHappiness = 0;

    [Header("Infected")]
    public bool isInfected = false;
    public bool isAmbulanceOnRoute = false;
    [SerializeField] private GameObject infectionParticles;
    private GameObject activeInfectionEffect;

    public void OnEnable()
    {
        if (ChunkManager.instance != null) { ChunkManager.instance.BuildingUtilitiesUpdated += OnUtilities; }
    }

    public void OnDisable()
    {
        if (ChunkManager.instance != null) { ChunkManager.instance.BuildingUtilitiesUpdated -= OnUtilities; }
    }

    public void OnUtilities()
    {
        if (ChunkManager.instance == null) return;

        ChunkManager.ChunkData chunk = ChunkManager.instance.GetChunkFromGridTile(gridPos);
        if (chunk == null) return;

        happiness = chunk.averageHappiness;

        if (happiness < 20f)
        {
            daysWithLowHappiness++;

            if (daysWithLowHappiness >= 3)
            {
                Debug.LogError($"[HOUSE DEATH] at ({gridPos.x}, {gridPos.y}) which is {chunk.chunkCord}. Chunk average happiness: {chunk.averageHappiness}, house local happiness {this.happiness}, days with low {daysWithLowHappiness}, chunk power: {chunk.HasEnoughPower} chunk water: {chunk.HasEnoughWater}");

                GameManager.instance.gridManager.forceRemoveElement(gridPos);
            }
        }
        else
        {
            daysWithLowHappiness = 0;
        }
    }
    public void Infect()
    {
        if (isInfected) { return; }
        isInfected = true;

        if (infectionParticles != null)
        {
            activeInfectionEffect = Instantiate(infectionParticles, transform.position + (Vector3.up * 0.5f), Quaternion.identity, transform);
        }
    }

    public void Heal()
    {
        if (!isInfected) { return; }
        isInfected = false;

        if (activeInfectionEffect != null) { Destroy(activeInfectionEffect); }

        isAmbulanceOnRoute = false; //Reset
    }
}